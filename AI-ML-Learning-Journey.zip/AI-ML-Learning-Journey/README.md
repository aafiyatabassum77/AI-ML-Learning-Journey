# AI & Machine Learning Learning Journey

A personal, practical notebook documenting my progress in AI, machine learning, and software development.

## What this repository contains

- **AI fundamentals:** clear notes on foundational concepts and model families.
- **Daily learning log:** short summaries of what I studied, what I understood, and what I want to explore next.
- **Practice and projects:** (to be added) code experiments and small projects that apply the concepts.

## Current learning topics

### Small Language Models (SLMs)
- What an SLM is and how it differs from a Large Language Model (LLM)
- The language-model workflow: data, tokenization, embeddings, model processing, training/adaptation, and inference
- Examples of compact language models and model families
- Use cases, benefits, limitations, and deployment considerations

See: [`01-AI-Fundamentals/Small-Language-Models.md`](01-AI-Fundamentals/Small-Language-Models.md)

## How I document a topic

For each topic, I aim to include:
1. A definition in my own words
2. How it works
3. A small example or analogy
4. Practical applications
5. Limitations and questions to investigate
6. A hands-on exercise when possible

## Note

These notes are learning material, not a claim that I have trained or deployed a model. I will add code and project evidence as I gain hands-on experience.
