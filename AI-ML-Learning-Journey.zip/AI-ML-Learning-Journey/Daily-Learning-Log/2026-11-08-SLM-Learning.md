# Daily Learning Log — 8 November 2026

## Topic studied
Small Language Models (SLMs), their workflow, examples, applications, benefits, and limitations.

## Main concepts
- Definition of an SLM
- Tokenization and embeddings
- Transformer architecture and attention
- Training, fine-tuning, and inference
- Examples: BERT, DistilBERT, MobileBERT, Phi-2, and Orca 2
- SLM vs LLM
- Use cases in customer support, mobile apps, education, coding assistance, healthcare administration, and IoT
- Advantages, limitations, and future opportunities

## My key takeaway
A smaller model can be a good choice for a focused task or a resource-constrained device, but model selection should be based on quality, privacy, latency, hardware, and cost—not size alone.

## Next learning goals
- Understand pretraining vs fine-tuning vs inference in more depth.
- Learn quantisation and knowledge distillation.
- Try running a small pretrained model and record its performance.

## Practical evidence
No model training or deployment is claimed in this entry. I will add an experiment when I complete one.
